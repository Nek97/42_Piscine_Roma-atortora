/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_operation.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: atortora <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/11 19:14:45 by atortora          #+#    #+#             */
/*   Updated: 2020/11/11 19:14:57 by atortora         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_operation_add(int a, int b)
{
	return (a + b);
}

int		ft_operation_minus(int a, int b)
{
	return (a - b);
}

int		ft_operation_devide(int a, int b)
{
	return (a / b);
}

int		ft_operation_multiply(int a, int b)
{
	return (a * b);
}

int		ft_operation_modulo(int a, int b)
{
	return (a % b);
}
